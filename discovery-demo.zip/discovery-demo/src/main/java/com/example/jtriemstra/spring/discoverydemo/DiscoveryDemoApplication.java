package com.example.jtriemstra.spring.discoverydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoveryDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoveryDemoApplication.class, args);
	}
}

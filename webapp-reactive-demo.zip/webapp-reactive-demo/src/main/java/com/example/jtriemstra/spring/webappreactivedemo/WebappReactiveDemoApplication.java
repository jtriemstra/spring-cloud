package com.example.jtriemstra.spring.webappreactivedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebappReactiveDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebappReactiveDemoApplication.class, args);
	}

}


package com.example.jtriemstra.spring.configdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigDemoApplication.class, args);
	}
}

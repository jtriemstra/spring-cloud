package com.example.jtriemstra.spring.webappolddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebappOldDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebappOldDemoApplication.class, args);
	}

}

